
data = [1,2,3,4]

print(data[0:1])