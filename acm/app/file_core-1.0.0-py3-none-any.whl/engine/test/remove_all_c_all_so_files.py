import os


def remove_c_and_so_files(directory):
    # 遍历目录中的所有文件和文件夹
    for root, dirs, files in os.walk(directory):
        for file in files:
            # 检查文件是否以 .c 或 .so 结尾
            if file.endswith('.c') or file.endswith('.so'):
                # 构建文件的完整路径
                file_path = os.path.join(root, file)
                # 删除文件
                os.remove(file_path)
                print(f"Removed {file_path}")


if __name__ == '__main__':
    directory = "/Users/douming/code/my_own_project/migrate-core"
    remove_c_and_so_files(directory)