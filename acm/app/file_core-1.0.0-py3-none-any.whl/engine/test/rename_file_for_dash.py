import os

def rename_files_in_directory(directory):
    # 遍历目录中的所有文件和文件夹
    for root, dirs, files in os.walk(directory):
        for file in files:
            # 构建原始文件的完整路径
            old_file_path = os.path.join(root, file)
            # 替换文件名中的 '-' 为 '_'
            new_file_name = file.replace('-', '_')
            # 构建新文件的完整路径
            new_file_path = os.path.join(root, new_file_name)
            # 重命名文件
            os.rename(old_file_path, new_file_path)
            print(f"Renamed {old_file_path} to {new_file_path}")

if __name__ == "__main__":
    # 请将此目录替换为你实际要操作的目录
    # directory = "/Users/douming/code/my_own_project/migrate-core/engine/move_data_node/dbf/backup"

    # directory = "/Users/douming/code/my_own_project/migrate-core/engine/move_data_node/dbf/backup2"

    # directory = "/Users/douming/code/my_own_project/migrate-core/engine/move_data_node/dbf/backup3"
    # directory = "/Users/douming/code/my_own_project/migrate-core/engine/move_data_node/xml"
    directory = "/Users/douming/code/my_own_project/migrate-core/engine/split/txt"
    rename_files_in_directory(directory)