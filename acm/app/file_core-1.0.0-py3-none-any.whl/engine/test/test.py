import os

def walk_in_directory(directory):
    # 遍历目录中的所有文件和文件夹
    for root, dirs, files in os.walk(directory):
        print(root)  # 当前目录路径
        print(dirs)  # 当前目录下的子目录列表
        print(files)  # 当前目录下的非目录子文件列表
        print("-----------------")


if __name__ == "__main__":
    # 请将此目录替换为你实际要操作的目录

    directory = "/Users/douming/code/my_own_project/migrate-core/engine/split/"
    walk_in_directory(directory)