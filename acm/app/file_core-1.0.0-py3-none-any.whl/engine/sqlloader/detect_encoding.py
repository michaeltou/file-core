import chardet

def detect_encoding(file_path):
    with open(file_path, 'rb') as f:
        raw_data = f.read()
        result = chardet.detect(raw_data)
        return result['encoding']

file_path = 'JSMX_02.DBF'
encoding = detect_encoding(file_path)
print(f"检测到的编码为: {encoding}")